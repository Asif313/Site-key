<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Drupal\custom_user\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class CustomUserController extends ControllerBase {

//Performing like/dislike operation
  public function getContent($api_key, $node_id, Request $request) {
    $site_config = $this->config('system.site');
    $siteapikey = $site_config->get('siteapikey');
    
    $node = \Drupal\node\Entity\Node::load($node_id);   
      
      if($siteapikey == $api_key && !empty($node)) {
        $nid = $node->id();
        $content_type = $node->getType();
        $jsonResponse = [];
      
        $values = \Drupal::entityQuery('node')->condition('nid', $nid)->execute();
        $jsonResponse = [
        'success' => 'true',
        'nid' => $nid,
        'apikey' => $siteapikey,
      ];
     }
    else {
      $jsonResponse = [
        'error' => 'access denied',
      ];
    } 
    return new JsonResponse($jsonResponse);
  }
}
